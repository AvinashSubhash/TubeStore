#!/bin/bash
echo -e "Enter the filename/n"
read foldername
mkdir Practice-Problems/$foldername/
cp TEMPLATE.cpp Practice-Problems/$foldername/$foldername.cpp