#include<bits/stdc++.h>
#define int1 long long int
#define endl "\n"
using namespace std;

void solution()
{
    //Solving area
    int1 n,a,result=0;
    cin>>n;
    vector<int> arr;
    while(n--) {
        cin>>a;
        arr.push_back(a);
    }
    if(arr.size()<=2)
        {
            if(arr.size()==2 && arr[0]==arr[1])
                result++;
            return result;
        }
    int1 prev=0,flag=0;
    for (int i=1;i<arr.size()-1;i++)
    {
        if(arr[i]+arr[i-1]==arr[i]+arr[i+1])
        {
            if(flag==0)
            {
                arr[i-1]+=arr[i];
                flag=1;
                prev=arr[i]+arr[i-1];
        }
    }

}

// for(auto x:array) cout<<x;
// vector<int> num(5,0); ==> [0,0,0,0,0]
// memset(data,-1,sizeof(data));
// sort(array1,array1+n);
// map<int,int> data; data[t]++;
//debug time
// begin=clock(); end=clock(); cout<<(double)(end-begin)/CLOCKS_PER_SEC;
int main()
{
    ios_base::sync_with_stdio(0);
    int1 t;
    cin>>t;
    while(t--)
    {
        solution();
    }
}