#include<iostream>
#define int1 long long intusing namespace std;
int main()
{
 int1 t,n,m,k,count;
 cin >>t;
 while(t--)
 {
     count=0;
     cin >> n >> m >> k;
     int1 array1[n][m];
     for (int1 i=0;i<n;i++)
     {
         for(int1 j=0;j<m;j++)
         cin >>array1[i][j];
     }
 }
}