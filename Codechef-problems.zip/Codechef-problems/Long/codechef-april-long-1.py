if len(set(input().split(' '))) < 3:
    print("Yes")
else:
    print("No")